package Files_func;

public class AllHeaders {

	
	public static String headersVariable() {
		
		String Authorization="Basic a3lwZW46VEhsb1JHZFRSRnBLTVVkRWRXTTRValZsTTJsaWV"
				+ "VbFBXamw0TVV4cFJWazJUM1ZGT0dOWFVHVkliMHhtY1hwYVFTOTZaM0ZuTVc1Tk5rU"
				+ "jZUSFIyVG5kWmVHNXdUSE5MVFZWRlRHTjFaa05NV25BNFZHazJjRUZPV1ZkWlUwcDRUR05Z"
				+ "YmxSd0t6UlpXSEZpY1c1QlprazRlVGx4WVZvck16UkNZMFIyYjJFelpVdExWa0ZwU1dsWWRu"
				+ "b3hWR1pPWnpoTmEzSkRObFUxYWpRMlQySlBRMEp3UTI4eGJtc3pXbEJXVTIxSFYzTjVOMDA0"
				+ "UkZOVWRWTlROMnhCYkRGVVVsVkJWRkZpUkZkUUwySk5UVEpNWlZWU1lYTlBXV0ZLTVZSVlQzcH"
				+ "hjME4zVlc0eVkwOVNZWGRNTDFsNFUxSllURXgwZFhwSlZHNUVUbnBDV2s5c1JITlFjSEUzYzBaTVFteDBhR1JRYUZSQldEZHJaRkpDVE"
				+ "RONGQxWlBZVGRaZFZwRVNFNHdMMmRoYUd0M0t6SnBZa2hvWVVKeVYweFFMeXN2VlZobEwzRlBRazk1YW5RMWQzTktlSFpaVW1rNWQySkpPVXRSUFQwPQ=="; 
		
		
		
		return Authorization;
	}
	
}
