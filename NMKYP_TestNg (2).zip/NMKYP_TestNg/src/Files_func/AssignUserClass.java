/*
 * package Files_func;
 * 
 * public class AssignUserClass {
 * 
 * public static void assignUserMethod() { int GetRoleID[] =
 * {21,6,17,28,30,3,10,1,23,20,8,27,12,16,33,22,13,7,15}; int GetRoleID[] =
 * {33}; //17,28,30,3,10,1,23,20,8,27,12,16,33,22,13,7,15};
 * 
 * for (int i=0;i<GetRoleID.length;i++) { UserMethods.getRoles(Slugid,
 * GetRoleID[i]);
 * 
 * if (LastName.equalsIgnoreCase("SR")){ int sr[] = {21,6}; for (int
 * i=0;i<sr.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * else if (LastName.equalsIgnoreCase("rev")){ int rev[] = {17,28,30,3}; for
 * (int i=0;i<rev.length;i++) { UserMethods.getRoles(Slugid,GetRoleID[i]); } }
 * 
 * 
 * else if (LastName.equalsIgnoreCase("sqc")){ int sqc[] = {10}; for (int
 * i=0;i<sqc.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * 
 * 
 * else if (LastName.equalsIgnoreCase("qc")){ int qc[] = {1}; for (int
 * i=0;i<qc.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * 
 * 
 * 
 * else if (LastName.equalsIgnoreCase("ssa")){ int ssa[] = {23}; for (int
 * i=0;i<ssa.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * 
 * else if (LastName.equalsIgnoreCase("sa")){ int sa[] = {20}; for (int
 * i=0;i<sa.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * 
 * 
 * else if (LastName.equalsIgnoreCase("svsr")){ int svsr[] = {8}; for (int
 * i=0;i<svsr.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * 
 * 
 * else if (LastName.equalsIgnoreCase("svr")){ int svr[] = {27}; for (int
 * i=0;i<svr.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * 
 * 
 * else if (LastName.equalsIgnoreCase("ceb")){ int ceb[] = {12}; for (int
 * i=0;i<ceb.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * 
 * 
 * else if (LastName.equalsIgnoreCase("sup")){ int sup[] = {16}; for (int
 * i=0;i<sup.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * 
 * else if (LastName.equalsIgnoreCase("anst")){ int anst[] = {33}; for (int
 * i=0;i<anst.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * else if (LastName.equalsIgnoreCase("monsr")){ int monsr[] = {22}; for (int
 * i=0;i<monsr.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); }}
 * 
 * else if (LastName.equalsIgnoreCase("monr")){ int monr[] = {13,7}; for (int
 * i=0;i<monr.length;i++) { UserMethods.getRoles(Slugid,GetRoleID[i]); } }
 * 
 * else if (LastName.equalsIgnoreCase("monssr")){ int monssr[] = {15}; for (int
 * i=0;i<monssr.length;i++) { UserMethods.getRoles(Slugid, GetRoleID[i]); } }
 * 
 * }
 * 
 * }
 */